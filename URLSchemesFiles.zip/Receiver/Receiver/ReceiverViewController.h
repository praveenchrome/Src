//
//  ReceiverViewController.h
//  Receiver
//
//  Created by Ajay Patel on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReceiverViewController : UIViewController {
    
}

@end
