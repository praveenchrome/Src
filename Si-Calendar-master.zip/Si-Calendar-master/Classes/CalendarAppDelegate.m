//
//  CalendarAppDelegate.m
//  Calendar
//
//  Created by Lloyd Bottomley on 29/04/10.
//  Copyright Savage Media Pty Ltd 2010. All rights reserved.
//

#import "CalendarAppDelegate.h"
#import "CalendarViewController.h"

@implementation CalendarAppDelegate

@synthesize window;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
	UINavigationController *navigation = [[UINavigationController alloc] init];
	CalendarViewController *controller = [[CalendarViewController alloc] init];
	[navigation pushViewController:controller animated:NO];
	[controller setCalendarViewControllerDelegate:self];
	
    // Override point for customization after app launch    
    [window addSubview:navigation.view];
    navigation.navigationBar.hidden = YES;
    [window makeKeyAndVisible];
	
	return YES;
}


- (void)calendarViewController:(CalendarViewController *)aCalendarViewController dateDidChange:(NSDate *)aDate {
	
    NSDate* sourceDate = aDate;
    
    NSTimeZone* sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    NSTimeZone* destinationTimeZone = [NSTimeZone systemTimeZone];
    
    NSInteger sourceGMTOffset = [sourceTimeZone secondsFromGMTForDate:sourceDate];
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:sourceDate];
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;
    
    NSDate* destinationDate = [[NSDate alloc] initWithTimeInterval:interval sinceDate:sourceDate];
    NSLog(@"Date set to: %@", destinationDate);
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
