//
//  CategoryViewController.m
//  GooglePlacesAPIDemo
//
//  Created by Praveen on 29/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CategoryViewController.h"
#import "PlacesTableViewController.h"


@implementation CategoryViewController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	arrCategories = [[NSArray alloc]initWithObjects:@"cafe",@"bar",@"beauty_salon",@"food",@"hospital",@"bank",@"atm",@"bakery",@"health",@"school",@"restaurant",@"train_station",@"shopping_mall",@"movie_theater",nil];
								
	NSLog(@"%d",[arrCategories count]);
	//arrCategories = [[arrCategories alloc] ini]
}


#pragma mark - Table view data source

//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//    NSString *sectionTitle = [self tableView:tableView titleForHeaderInSection:section];
//    if (sectionTitle == nil) {
//        return nil;
//    }
//	
//    // Create label with section title
//    UILabel *label = [[[UILabel alloc] init] autorelease];
//    label.frame = CGRectMake(20, 6, 300, 30);
//    label.backgroundColor = [UIColor clearColor];
//    label.textColor = [UIColor colorWithHue:(136.0/360.0)  // Slightly bluish green
//                                 saturation:1.0
//                                 brightness:0.60
//                                      alpha:1.0];
//    label.shadowColor = [UIColor whiteColor];
//    label.shadowOffset = CGSizeMake(0.0, 1.0);
//    label.font = [UIFont boldSystemFontOfSize:16];
//    label.text = sectionTitle;
//	
//    // Create header view and add label as a subview
//    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 40)];
//    [view autorelease];
//    [view addSubview:label];
//	
//    return view;
//}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
	
	return @"Category";
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	
    // Return the number of rows in the section.
    return [arrCategories count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    //cell.textLabel.text = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:0] stringValue];
    
   // cell.detailTextLabel.text = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:1] stringValue];
	cell.textLabel.text =[NSString stringWithFormat:@"%@",[arrCategories objectAtIndex:indexPath.row]] ;
	NSLog(@"%@",[arrCategories objectAtIndex:indexPath.row]);
    
    return cell;
}




#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	 rad = [txtfieldRad.text intValue];
	selectedCategory = [arrCategories objectAtIndex:indexPath.row];
    NSString *str = [arrCategories objectAtIndex:indexPath.row];
    
    PlacesTableViewController *plcTblViewController = [[PlacesTableViewController alloc] init];
    
	plcTblViewController.selctedCat = [NSString stringWithFormat:@"%@",str];
	plcTblViewController.selctedRad = [NSString stringWithFormat:@"%@",txtfieldRad.text];
	plcTblViewController.categoryName = [arrCategories objectAtIndex:indexPath.row];
	//NSLog(@"categoryName = %@",[arrCategories objectAtIndex:indexPath.row]);
	rad = [[NSString stringWithFormat:@"%@",txtfieldRad.text] intValue];
    [self.navigationController pushViewController:plcTblViewController animated:YES];
    [plcTblViewController release];
}




#pragma mark -
#pragma mark UITextFieldDelegate 
// called when 'return' key pressed. return NO to ignore.

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	return YES;
	
	//[(MyTextField*)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	
	[textField resignFirstResponder];
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
	
	
	return YES;
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
