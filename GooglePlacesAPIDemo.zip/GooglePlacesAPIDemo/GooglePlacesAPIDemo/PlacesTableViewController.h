//
//  PlacesTableViewController.h
//  GooglePlacesAPIDemo
//
//  Created by Training on 6/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GDataXMLNode.h"
#import "MapViewController.h"
#import "MyMapAnnot.h"

@interface PlacesTableViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,MKMapViewDelegate,MKAnnotation> {
    
    MKMapView *mapView;
	MyMapAnnot *mapAnnotObject;
    CLLocationCoordinate2D globalCords;
    NSMutableArray *placesOutputArray;
	NSMutableArray *placesDetailArray;
    GDataXMLDocument *xmlDocument;
    MapViewController *mapViewC;
	NSString *selctedCat;
	NSString *selctedRad;
    UITableView *tblAddress;
	NSString *categoryName;
	NSString *strImgUrl;
}

@property(nonatomic,retain)NSString *selctedCat,*selctedRad,*categoryName;

-(void)ParseXML_of_Google_PlacesAPI;



@end
