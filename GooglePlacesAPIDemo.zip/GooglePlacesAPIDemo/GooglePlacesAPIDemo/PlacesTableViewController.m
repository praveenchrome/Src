//
//  PlacesTableViewController.m
//  GooglePlacesAPIDemo
//
//  Created by Training on 6/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//  34.0522222,-118.2427778

#import "PlacesTableViewController.h"
#define PlacesURL @"https://maps.googleapis.com/maps/api/place/search/xml?location=28.62099,77.38116&radius=5000&types=food&sensor=false&key=AIzaSyCEKTuUlu5cvGZl-09V1ZUCdd8MJoxKU2U"

@implementation PlacesTableViewController

@synthesize selctedCat,selctedRad,categoryName;

//- (id)initWithStyle:(UITableViewStyle)style
//{
//	NSLog(@"initWithStyle");
//	NSLog(@"rad = %d %@",rad,selectedCategory);
//    self = [super initWithStyle:style];
//    if (self) {
//        // Custom initialization
//        self.selctedCat = [[NSString alloc] init];
//        placesOutputArray = [[NSMutableArray alloc]init];
//        [self ParseXML_of_Google_PlacesAPI];
//        
//    }
//    return self;
//}

-(void)parseXML{
	NSLog(@"initWithStyle");
	NSLog(@"rad = %d %@",rad,selectedCategory);
    //self = [super initWithStyle:style];
 
        // Custom initialization
        self.selctedCat = [[NSString alloc] init];
        placesOutputArray = [[NSMutableArray alloc]init];
        [self ParseXML_of_Google_PlacesAPI];
}

-(void)ParseXML_of_Google_PlacesAPI
{
	NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/search/xml?location=28.62099,77.38116&radius=%d&types=%@&sensor=false&key=AIzaSyCEKTuUlu5cvGZl-09V1ZUCdd8MJoxKU2U",rad,selectedCategory];
	NSLog(@"url = %@",strUrl);
    NSURL *googlePlacesURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@",strUrl]];
    NSData *xmlData = [NSData dataWithContentsOfURL:googlePlacesURL];
    xmlDocument = [[GDataXMLDocument alloc]initWithData:xmlData options:0 error:nil];
    
    NSArray *arr = [xmlDocument.rootElement elementsForName:@"result"];
    
    for(GDataXMLElement *e in arr )
    {
        [placesOutputArray addObject:e];
    }
    
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
	NSLog(@"viewDidLoad");
    [super viewDidLoad];
	[self parseXML];
	self.selctedCat = [[NSString alloc] init];
	self.categoryName = [[NSString alloc] init];
	NSLog(@"placesOutputArray = %@",placesOutputArray);
    tblAddress = [[UITableView alloc] initWithFrame:CGRectMake(0, 180, 320, 240)];
    tblAddress.delegate = self;
    tblAddress.dataSource = self;
	[self.view addSubview:tblAddress];
	NSLog(@"categoryName = %@",self.categoryName);
    
    
	mapView = [[MKMapView alloc]initWithFrame:CGRectMake(10, 10, 300, 160)];
	mapView.delegate = self;
	[self.view addSubview:mapView];
	[self setPinOnMap];
	

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)setPinOnMap{
	
	NSString *str;
	double lat,lng;
	for(int i = 0;i<[placesOutputArray count];i++){
		 
		 str = [[[placesOutputArray objectAtIndex:i] childAtIndex:0] stringValue];
		 lat = [[[[[[[[placesOutputArray objectAtIndex:i]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:0]stringValue]doubleValue];
    
         lng = [[[[[[[[placesOutputArray objectAtIndex:i]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:1] stringValue] doubleValue];
	
	     CLLocationCoordinate2D _cords = {lat,lng};
	     
		 strImgUrl = [[[[placesOutputArray objectAtIndex:i] elementsForName:@"icon"] objectAtIndex:0] stringValue];
		
		 //NSLog(@"strImgUrl = %@",strImgUrl);
		
		
	     mapAnnotObject = [[MyMapAnnot alloc]initWithName:str andCoordinates:_cords];
	     CLLocationCoordinate2D cord = {_cords.latitude,_cords.longitude};
         MKCoordinateSpan spn = {0.01,0.01};
         MKCoordinateRegion reg = {cord,spn};
	     [mapView setRegion:reg];
	     [mapView addAnnotation:mapAnnotObject];
	}
	
}

- (MKAnnotationView *)mapView:(MKMapView *)theMapView viewForAnnotation:(id <MKAnnotation>)annotation{
	
	MKAnnotationView *annotationView = [[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:nil] autorelease];
	annotationView.canShowCallout = YES;
	
	UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",strImgUrl]]]];
	
	//UIImage *image =[UIImage imageNamed:@"icon-map-pointer.png"];
	annotationView.image = image;
	return annotationView;
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
	
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
	NSLog(@"self.selctedCat = %@",self.selctedCat);
	NSLog(@"self.selctedCat = %@",self.categoryName);
	return @"List";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    return [placesOutputArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"check table");
	static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    cell.textLabel.text = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:0] stringValue];
    
    cell.detailTextLabel.text = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:1] stringValue];
	NSLog(@"address = %@",[placesOutputArray objectAtIndex:indexPath.row]);
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:0] stringValue];
    
    //parsing for latitude and longitude
    
    double lat = [[[[[[[[placesOutputArray objectAtIndex:indexPath.row]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:0]stringValue]doubleValue];
    
    double lng = [[[[[[[[placesOutputArray objectAtIndex:indexPath.row]elementsForName:@"geometry"] objectAtIndex:0] elementsForName:@"location"] objectAtIndex:0] childAtIndex:1] stringValue] doubleValue];
	
	NSString *ref = [[[[placesOutputArray objectAtIndex:indexPath.row] elementsForName:@"reference"] objectAtIndex:0] stringValue];
	
	NSLog(@"ref = %@",ref);
    
    CLLocationCoordinate2D _cords = {lat,lng};
    [self callDetailAPI:ref];
    
  mapViewC = [[MapViewController alloc]initWithNibName:nil bundle:nil bankName:str andCoordinates:_cords];
	mapViewC.strAddress = [[[placesOutputArray objectAtIndex:indexPath.row] childAtIndex:1] stringValue];
	mapViewC.strPhoneNo = [[[[placesDetailArray objectAtIndex:0] elementsForName:@"formatted_phone_number"] objectAtIndex:0] stringValue];
	if([[[placesDetailArray objectAtIndex:0] elementsForName:@"address_component"] count]>5)
	mapViewC.strPin = [[[[[[placesDetailArray objectAtIndex:0] elementsForName:@"address_component"] objectAtIndex:5] elementsForName:@"long_name"] objectAtIndex:0] stringValue];
	mapViewC.strImgUrl = [[[[placesDetailArray objectAtIndex:0] elementsForName:@"icon"] objectAtIndex:0] stringValue];

  [self.navigationController pushViewController:mapViewC animated:YES];
    
    
    
}

-(void)callDetailAPI:(NSString*)ref{
	
	placesDetailArray = [[NSMutableArray alloc] init];
	
	NSString *strUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/details/xml?reference=%@&sensor=false&key=AIzaSyCEKTuUlu5cvGZl-09V1ZUCdd8MJoxKU2U",ref];
	NSLog(@"url = %@",strUrl);
    NSURL *googlePlacesDetailURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@",strUrl]];
    NSData *xmlData = [NSData dataWithContentsOfURL:googlePlacesDetailURL];
	xmlDocument = [[GDataXMLDocument alloc]initWithData:xmlData options:0 error:nil];
    
    NSArray *arr = [xmlDocument.rootElement elementsForName:@"result"];
    
    for(GDataXMLElement *e in arr )
    {
        [placesDetailArray addObject:e];
		
    }
}

@end
