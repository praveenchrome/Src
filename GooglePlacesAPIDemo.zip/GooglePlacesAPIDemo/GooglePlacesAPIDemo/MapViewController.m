//
//  MapViewController.m
//  GooglePlacesAPIDemo
//
//  Created by Training on 6/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MapViewController.h"


@implementation MapViewController
@synthesize strAddress,strPhoneNo,strPin,strImgUrl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil bankName:(NSString*)_name andCoordinates:(CLLocationCoordinate2D)bankcords
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        bankName = _name;
        globalCords = bankcords;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    [super loadView];
    //mpView = [[MKMapView alloc]initWithFrame:self.view.bounds];
	
	mpView = [[MKMapView alloc]initWithFrame:CGRectMake(10, 20, 200, 200)];
	//mpView.delegate = self;
	lblAddress = [[UILabel alloc] initWithFrame:CGRectMake(140, 230, 100, 50)];
	txtViewAddress = [[UITextView alloc] initWithFrame:CGRectMake(60, 270, 200, 100)];
	
	UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",self.strImgUrl]]]];
	imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(210, 20, image.size.width, image.size.height)];
	imgViewIcon.image = image;
	//imgViewIcon.backgroundColor = [UIColor redColor];
	lblAddress.text = @"Address";
    txtViewAddress.text = [NSString stringWithFormat:@"%@\nPhone:%@\nPin:%@",self.strAddress,self.strPhoneNo,self.strPin];
	txtViewAddress.userInteractionEnabled = NO;
	txtViewAddress.backgroundColor = [UIColor lightGrayColor];
    mapAnnotObject = [[MyMapAnnot alloc]initWithName:bankName andCoordinates:globalCords];
    
    CLLocationCoordinate2D cord = {globalCords.latitude,globalCords.longitude};
    MKCoordinateSpan spn = {0.01,0.01};
    MKCoordinateRegion reg = {cord,spn};
    
    [mpView setRegion:reg];
    
    [mpView addAnnotation:mapAnnotObject];
    [self.view addSubview:mpView];
	[self.view addSubview:lblAddress];
	[self.view addSubview:txtViewAddress];
	[self.view addSubview:imgViewIcon];
}

- (MKAnnotationView *)mapView:(MKMapView *)theMapView viewForAnnotation:(id <MKAnnotation>)annotation{
	
	MKAnnotationView *annotationView = [[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:nil] autorelease];
	annotationView.canShowCallout = YES;
	//UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",self.strImgUrl]]]];
	//UIImage *image =[UIImage imageNamed:@"icon-map-pointer.png"];
	//annotationView.image = image;
	return annotationView;
}


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
