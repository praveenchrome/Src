//
//  MapViewController.h
//  GooglePlacesAPIDemo
//
//  Created by Training on 6/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapKit/MapKit.h"
#import "MyMapAnnot.h"


@interface MapViewController : UIViewController<MKMapViewDelegate> {
    
    
    MKMapView *mpView;
	UIImageView *imgViewIcon;
    MyMapAnnot *mapAnnotObject;
    NSString *bankName;
    CLLocationCoordinate2D globalCords;
	UILabel *lblAddress;
	UITextView *txtViewAddress;
	NSString *strAddress;
	NSString *strPhoneNo;
	NSString *strPin;
	NSString *strImgUrl;
	
	
    
    
}

@property(nonatomic,retain)NSString *strAddress,*strPhoneNo,*strPin,*strImgUrl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil bankName:(NSString*)_name andCoordinates:(CLLocationCoordinate2D)bankcords;

@end
