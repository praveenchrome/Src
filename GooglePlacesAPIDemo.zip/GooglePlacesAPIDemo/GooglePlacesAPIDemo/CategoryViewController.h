//
//  CategoryViewController.h
//  GooglePlacesAPIDemo
//
//  Created by Praveen on 29/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CategoryViewController : UIViewController<UITableViewDelegate> {
	
	IBOutlet UITableView *tblViewCategory;
	IBOutlet UITextField *txtfieldRad;
	NSArray *arrCategories;

}

@end
