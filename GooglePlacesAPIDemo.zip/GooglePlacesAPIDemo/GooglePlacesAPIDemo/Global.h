//
//  Global.h
//  FakeMagazineCreator
//
//  Created by chrome infotech on 14/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#define Debug_Flag YES
#define inAppPurchaseProductID1 @"com.chrome.fakemagazine.item1"

BOOL isIPad;
int btnBackTag;
int btnDoneTag;
BOOL isSplashActive;
long int rad;
NSString*  selectedCategory;
